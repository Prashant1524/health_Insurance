package com.insurance.uhg.userservice.model;

public enum ERole {
	
	ROLE_USER,
	ROLE_ADMIN
	
}
